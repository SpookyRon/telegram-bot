module.exports = require('neostandard')({
  env: [
    'browser',
    'node'
  ]
})
