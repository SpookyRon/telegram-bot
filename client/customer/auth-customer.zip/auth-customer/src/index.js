import './component/font-loader.js'
import './component/page.js'
import './component/notfound.js'
import './component/login.js'
