export default {
  base: '/login',
  server: {
    port: 5173
  }
}